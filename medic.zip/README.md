# Portal Server 24-7

### ER Diagram

![Alt text](image.png)